import React from 'react';
import ReactDOM from 'react-dom';
//import './index.css';
import App from './App';
import Add from './Components/Add';
import Main from './Components/Main';
import HelloWorldExample from './Components/HelloWorldExample';
import registerServiceWorker from './registerServiceWorker';

alert('It Works!!!');
console.log('It Works!!! from console');
ReactDOM.render(<App />, document.getElementById('root1'));
ReactDOM.render(<Add />, document.getElementById('root2'));
ReactDOM.render(<HelloWorldExample />, document.getElementById('root3'));
ReactDOM.render(<Main />, document.getElementById('root4'));
registerServiceWorker();
