import React, { Component } from 'react';

class Add extends Component {
  constructor() {
    super();
    this.state = {
        total : ''
    }
  }
  calculateTotal() {
      alert('calculateTotal');
      console.log(this.refs.number1.value);
      console.log(this.refs.number2.value);
      if(this.refs.number2.value=="") {
        this.setState({total : this.refs.number1.value});
      }else if (this.refs.number1.value=="") {
        this.setState({total : this.refs.number2.value});
      }else {
        var total = parseInt(this.refs.number1.value)+parseInt(this.refs.number2.value);
        this.setState({total : total});
      }


  }
  render() {
    alert('render called');
    //  <label>Enter First Number: <input type="text" ref="number1" onBlur={this.calculateTotal.bind(this)}/></label><br/>
    return (
      <div>
        <label>Enter First Number: <input type="text" ref="number1"/></label><br/>
        <label>Enter Second Number: <input type="text" ref="number2" onBlur={this.calculateTotal.bind(this)}/></label><br/>
        <br/>
        {this.state.total}
      </div>

    );

  }
}

export default Add;
