import React, { Component } from 'react';
import $ from 'jquery';

class EditButton extends Component {
    edit(id) {
        alert('edit button clicked =====> '+id);
    }
    render() {
        return (<input type="radio" name="bookItems" onChange={this.edit.bind(this,this.props.id)}></input>);
    }

}

export default EditButton;
