import React, { Component } from 'react';

class HelloWorldExample extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div>
        <h1>Hello World!!!!</h1>
      </div>

    );

  }
}

export default HelloWorldExample;
