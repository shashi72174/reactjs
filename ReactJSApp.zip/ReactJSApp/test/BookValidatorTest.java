import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import junit.framework.TestCase;

@RunWith(Parameterized.class)
public class BookValidatorTest extends TestCase{
	Book book = null;
	
	public BookValidatorTest(Book book) {
		super();
		this.book = book;
	}

	@Parameters
	public static List<Book> generateData() {
		Connection con = null;
		List<Book> list = new ArrayList<Book>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "VIBHU", "BHUVI");
			ps = con.prepareStatement("select * from book e");
			rs = ps.executeQuery();
			while(rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getInt(1));
				book.setIsbn(rs.getInt(2));
				book.setBookName(rs.getString(3));
				book.setBookPrice(rs.getDouble(4));
				list.add(book);
			}
			return list;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				con.close();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		}
		return null;
		
	}
	
	@Test
	public void validateBook() {
		assertEquals(true, new BookValidator().validate(book));
	}
	
}
