
public class BookValidator {
	public boolean validate(Book book) {
		if(book.getBookId()==82)
			return true;
		return false;
		
	}
}
