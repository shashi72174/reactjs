module.exports = {
        "messages":{
            "X":{"conversations":[
                {
                    "who":"XX",
                    "text":"Hi",
                    "time":new Date(2016, 4, 5, 15, 10, 0, 0)
                },
                {
                    "who":"Me",
                    "text":"Hi buddy",
                    "time":new Date(2016, 4, 5, 15, 11, 0, 0)
                },
                {
                    "who":"XX",
                    "text":"H r u ",
                    "time":new Date(2016, 4, 5, 15, 12, 0, 0)
                }
            ]
            },
            "Y":{"conversations":[
                {
                    "who":"YY",
                    "text":"Hi",
                    "time":new Date(2016, 4, 5, 15, 10, 0, 0)
                },
                {
                    "who":"Me",
                    "text":"Hi buddy",
                    "time":new Date(2016, 4, 5, 15, 11, 0, 0)
                },
                {
                    "who":"YY",
                    "text":"H r u ",
                    "time":new Date(2016, 4, 5, 15, 12, 0, 0)
                }
            ]}
        }
};