var HelloWorldExample = React.createClass({
				render : function() {
					alert('render function called');
					return (<div><p>Hello World from ReactJS!!!</p></div>);
				}

			});
			ReactDOM.render(<HelloWorldExample />,document.getElementById('helloWorld'));