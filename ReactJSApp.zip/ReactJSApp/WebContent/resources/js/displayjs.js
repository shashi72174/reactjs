$(document).ready(function(e) {
	var tabcontent = $('.tabcontent');
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    document.getElementById("London").style.display = "block";
    $("#tab1").click();
    $("#tab1").focus();
    var tablinks = $('.tablinks');
	for(var i=0;i<tablinks.length;i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}
    
    $("#London").show('fast');
	$("#Paris").hide('fast');
	$("#Tokyo").hide('fast');
	$('#bookTable').remove();
	$.ajax({
		type : 'GET',
		url : 'getBookDetails',
		data: {action : "getBookDetails"},
		success : function(data) {
			alert("data ===== "+data);
			var data1 = JSON.stringify(data);
			var jsonData = JSON.parse(data1);
			alert("jsonData ===== "+jsonData.books.length);
	        var table = $("<table />");
	        table[0].border = "1";
	        table[0].id= "bookTable";
	        var colCount = [];
        	for(var key in jsonData.books[0]) {
        		if(key!="BOOKID") {
	        		if(colCount.indexOf(key)===-1) {
	        			colCount.push(key);
	        		}	
        		}
        	}
	        var row = $(table[0].insertRow(-1));
	        for(var i=0;i<colCount.length;i++) {
	        	var headerCell = $("<th />");
	        	headerCell.html(colCount[i].toUpperCase());
	        	row.append(headerCell);
	        }
	        var editCell = $("<th />");
	        editCell.html("EDIT");
	        row.append(editCell);
	        for(var i=0;i<jsonData.books.length;i++) {
	        	var row = $(table[0].insertRow(-1));
	        	for(var j=0;j<colCount.length;j++) {
	   				var data = $("<td />");
		       		data.html(jsonData.books[i][colCount[j]]);
		       		row.append(data);     	
	        	}
	        	var edit = $("<td/>")
	        	var editId = jsonData.books[i].BOOKID;
	        	var something = "<input type=\"button\" value=\"edit\" onclick=\"editBookDetails("+editId+")\"></input>";
	        	var buttonTag = $(something);
	        	edit.html(buttonTag);
	        	row.append(edit);
	        	
	        }
	        var divId=$('#divId');
	        divId.attr("align","center");
	        divId.html();
	        divId.append(table);
	        
	        $("#dataGrid").jqGrid({
	            //url: 'http://localhost:9090/SpringMVCProject/getBookDetails',
	            datatype: 'local',
	            //data : jsonData,
	            colModel: [
	                { label: 'ISBN', name: 'isbn', width: 100 },
	                { label: 'BOOKPRICE', name: 'bookPrice', width: 80 },
	                { label: 'BOOKID', name: 'bookId', width: 80 },
	                { label: 'BOOKNAME', name: 'bookName', width: 80 }
	               
	            ],
	            gridview: true,
	            autoencode: true,
	            loadonce: true,
	   		 viewrecords: true,
	            width: 780,
	            height: 200,
	            rowNum: 10,
	            pager: "#jqGridPager",
	            caption: "Book Details"
	        });
	        alert('fdsfsdfsdfsd');
	        var names = ["BOOKID", "ISBN", "BOOKNAME", "BOOKPRICE"];
			var mydata = [];
			alert("jsonData.length ======> "+jsonData.books.length);
			for (var i = 0; i < jsonData.books.length; i++) { //data.length ====> 2
				mydata[i] = {};
				for (var j = 0; j < names.length; j++) {
					mydata[i][names[j]] = jsonData.books[i][names[j]];
				}
			}
			alert(mydata);
			console.log(mydata);
			for (var i = 0; i <= mydata.length; i++) {
				alert(mydata[i][names[0]]+"\t"+mydata[i][names[1]]+"\t"+mydata[i][names[2]]+"\t"+mydata[i][names[3]]);
				$("#dataGrid").jqGrid('addRowData', i + 1, mydata[i]);
			}
		},
	});
		var addDivDialog = $('#dialog');
		addDivDialog.dialog({
			modal : true,
			autoOpen : false,
			buttons : {
				'Save' : function() {
					var isbn = $('#isbn').val();
					var bookName = $('#bookName').val();
					var bookPrice = $('#bookPrice').val();
					var book = {
					"isbn" : isbn,
					"bookName" : bookName,
					"bookPrice" : bookPrice
					}
					console.log(book);
					var jsonString = JSON.stringify(book);
					alert(jsonString);
					$.ajax({
						type : 'POST',
						url : 'saveBookDetails',
						accept: 'application/json',
						contentType : 'application/json; charset=utf-8',
						data: jsonString,
						success : function(data) {
							var tablinks = $('.tablinks');
							for(var i=0;i<tablinks.length;i++) {
								tablinks[i].className = tablinks[i].className.replace(" active", "");
							}
							$("#London").show('fast');
							$("#Paris").hide('fast');
							$("#Tokyo").hide('fast');
							$('#bookTable').remove();
							$.ajax({
								type : 'GET',
								url : 'getBookDetails',
								data: {action : "getBookDetails"},
								success : function(data) {
									var data1 = JSON.parse(data);
							        var table = $("<table />");
							        table[0].border = "1";
							        table[0].id= "bookTable";
							        var colCount = [];
						        	for(var key in data1.books[0]) {
						        		if(key!="BOOKID") {
							        		if(colCount.indexOf(key)===-1) {
							        			colCount.push(key);
							        		}	
						        		}
						        	}
							        var row = $(table[0].insertRow(-1));
							        for(var i=0;i<colCount.length;i++) {
							        	var headerCell = $("<th />");
							        	headerCell.html(colCount[i].toUpperCase());
							        	row.append(headerCell);
							        }
							        var editCell = $("<th />");
							        editCell.html("EDIT");
							        row.append(editCell);
							        for(var i=0;i<data1.books.length;i++) {
							        	var row = $(table[0].insertRow(-1));
							        	for(var j=0;j<colCount.length;j++) {
							   				var data = $("<td />");
								       		data.html(data1.books[i][colCount[j]]);
								       		row.append(data);     	
							        	}
							        	var edit = $("<td/>")
							        	var editId = data1.books[i].BOOKID;
							        	var something = "<input type=\"button\" value=\"edit\" onclick=\"editBookDetails("+editId+")\"></input>";
							        	var buttonTag = $(something);
							        	edit.html(buttonTag);
							        	row.append(edit);
							        }
							        var divId=$('#divId');
							        divId.attr("align","center");
							        divId.html();
							        divId.append(table);
								},
							});
						}
						
					});
					$('#isbn').val('');
					$('#bookPrice').val('');
					$('#bookName').val('');
					addDivDialog.dialog('close');
				},
				'Cancel' : function() {
					$('#isbn').val('');
					$('#bookPrice').val('');
					$('#bookName').val('');
					addDivDialog.dialog('close');
				}
				
			}
			
		});	
		$('#addId').click(function(){
			addDivDialog.dialog('open');
			
		});	
	
		$('#tab1').click(function(e) {
			/*var text = $(this).text();
			alert(text);*/
			var tablinks = $('.tablinks');
			for(var i=0;i<tablinks.length;i++) {
				tablinks[i].className = tablinks[i].className.replace(" active", "");
			}
		    e.currentTarget.className += " active";
			$("#London").show('fast');
			$("#Paris").hide('fast');
			$("#Tokyo").hide('fast');
			$('#bookTable').remove();
			$.ajax({
				type : 'GET',
				url : 'getBookDetails',
				data: {action : "getBookDetails"},
				success : function(data) {
					var data1 = JSON.parse(data);
			        var table = $("<table />");
			        table[0].border = "1";
			        table[0].id= "bookTable";
			        var colCount = [];
		        	for(var key in data1.books[0]) {
		        		if(key!="BOOKID") {
			        		if(colCount.indexOf(key)===-1) {
			        			colCount.push(key);
			        		}	
		        		}
		        	}
			        var row = $(table[0].insertRow(-1));
			        for(var i=0;i<colCount.length;i++) {
			        	var headerCell = $("<th />");
			        	headerCell.html(colCount[i].toUpperCase());
			        	row.append(headerCell);
			        }
			        var editCell = $("<th />");
			        editCell.html("EDIT");
			        row.append(editCell);
			        for(var i=0;i<data1.books.length;i++) {
			        	var row = $(table[0].insertRow(-1));
			        	for(var j=0;j<colCount.length;j++) {
			   				var data = $("<td />");
				       		data.html(data1.books[i][colCount[j]]);
				       		row.append(data);     	
			        	}
			        	var edit = $("<td/>")
			        	var editId = data1.books[i].BOOKID;
			        	var something = "<input type=\"button\" value=\"edit\" onclick=\"editBookDetails("+editId+")\"></input>";
			        	var buttonTag = $(something);
			        	edit.html(buttonTag);
			        	row.append(edit);
			        }
			        var divId=$('#divId');
			        divId.attr("align","center");
			        divId.html();
			        divId.append(table);
				},
			});
			
			
		});
    
	$('#tab2').click(function(e) {
		/*var text = $(this).text();
		alert(text);*/
		var tablinks = $('.tablinks');
		for(var i=0;i<tablinks.length;i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
	    e.currentTarget.className += " active";
		$("#London").hide('fast');
		$("#Paris").show('fast');
		$("#Tokyo").hide('fast');
	});

	$('#tab3').click(function(e) {
		/*var text = $(this).text();
		alert(text);*/
		var tablinks = $('.tablinks');
		for(var i=0;i<tablinks.length;i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
	    e.currentTarget.className += " active";
		$("#London").hide('fast');
		$("#Paris").hide('fast');
		$("#Tokyo").show('fast');
	});
	
});

function editBookDetails(id) {
	var editDivDialog = $('#editDialog').css('display', '');
	$('#editIsbn').val('');
	$('#editBookName').val('');
	$('#editBookPrice').val('');
	$.ajax({
		type : 'GET',
		url : 'getBookById',
		data: {bookId : id},
		success : function(data) {
			var data1 = JSON.parse(data);
			$('#editIsbn').val(data1.ISBN);
			$('#editBookName').val(data1.BOOKNAME);
			$('#editBookPrice').val(data1.BOOKPRICE);
		}
		
	});
	editDivDialog.dialog({
		modal : true,
		autoOpen : false,
		buttons : {
			'Update' : function() {
				
			},
			'Cancel' : function() {
				editDivDialog.dialog('close');
			}
		}
	});
	editDivDialog.dialog('open');
}