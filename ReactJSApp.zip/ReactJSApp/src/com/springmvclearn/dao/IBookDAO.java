package com.springmvclearn.dao;

import java.util.List;

import com.springmvclearn.entities.Book;

public interface IBookDAO {

	public List<Book> findAll() throws Exception;

	public boolean saveBookDetails(Book book);

	public Book getBook(Integer bookId) throws Exception;
	
	/*public List<Book> findAll(Integer pageNum,Integer recordsPerPage) throws Exception;
	
	public List<Book> findAll() throws Exception;
	
	
	
	public boolean deleteBook(Integer bookId) throws Exception;

	public boolean save(Book book);*/
}
