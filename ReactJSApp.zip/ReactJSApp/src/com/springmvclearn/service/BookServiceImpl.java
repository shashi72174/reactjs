package com.springmvclearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvclearn.dao.IBookDAO;
import com.springmvclearn.entities.Book;

@Service
public class BookServiceImpl implements IBookService {
	
	@Autowired
	private IBookDAO iBookDAO;
	
	@Override
	public List<Book> findAll() throws Exception {
		// TODO Auto-generated method stub
		return iBookDAO.findAll();
	}

	@Override
	public boolean saveBookDetails(Book book) {
		// TODO Auto-generated method stub
		return iBookDAO.saveBookDetails(book);
	}
	
	@Override
	public Book getBook(Integer bookId)  throws Exception  {
		// TODO Auto-generated method stub
		return iBookDAO.getBook(bookId);
	}
		
	/*@Override
	public List<Book> findAll(Integer pageNum,Integer recordsPerPage) throws Exception {
		// TODO Auto-generated method stub
		return bookDAO.findAll(pageNum,recordsPerPage);
	}*/

	/*	

	@Override
	public boolean deleteBook(Integer bookId) throws Exception {
		// TODO Auto-generated method stub
		return bookDAO.deleteBook(bookId);
	}

	@Override
	public boolean save(Book book) {
		// TODO Auto-generated method stub
		return bookDAO.save(book);
		
	}*/

	
}
