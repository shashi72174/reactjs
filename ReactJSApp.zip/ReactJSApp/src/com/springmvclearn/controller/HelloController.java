package com.springmvclearn.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.Controller;

@Controller
public class HelloController {// implements Controller {
	
	/*@RequestMapping(value = "/hello",method=RequestMethod.GET)
	public ModelAndView sayHello(@RequestParam String name) {
		System.out.println("Came inside sayHello method");
		System.out.println(name);
		Map<String,String> map = new HashMap<String,String>();
		map.put("msg", name);
		return new ModelAndView("welcome", map);
	}*/
	
	@RequestMapping(value = "/hello",method=RequestMethod.GET)
	public ModelAndView sayHello() {
		System.out.println("Came inside sayHello method");
		return new ModelAndView("welcome");
	}

	/*@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Came inside handle request method");
		System.out.println(req.getParameter("name"));
		Map<String,String> map = new HashMap<String,String>();
		map.put("msg", req.getParameter("name"));
		return new ModelAndView("welcome", map);
	}*/
	
	@RequestMapping(value = "/hi/{name}",method=RequestMethod.GET)
	public ModelAndView sayHi(@PathVariable("name") String pathName){
		System.out.println("Came inside sayHi method");
		System.out.println(pathName);
		Map<String,String> map = new HashMap<String,String>();
		map.put("msg", pathName);
		return new ModelAndView("HelloPage",map);
	}
}
