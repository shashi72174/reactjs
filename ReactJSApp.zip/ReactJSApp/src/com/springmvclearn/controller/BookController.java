package com.springmvclearn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springmvclearn.entities.Book;
import com.springmvclearn.service.IBookService;

@RestController
public class BookController {

	@Autowired
	private IBookService iBookService;

	@RequestMapping(value = "/getBookDetails", method = RequestMethod.GET, produces = { "application/json" })
	public String getBookDetails(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("getBookDetails");
		System.out.println(request.getParameter("action"));
		List<Book> bookList = null;
		try {
			bookList = iBookService.findAll();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		JSONObject jsonObject = new JSONObject();
		/*
		 * JSONArray jsonArray = new JSONArray(bookList);
		 * System.out.println(jsonArray);
		 */
		JSONArray jsonArray = new JSONArray();
		for (Book book : bookList) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("BOOKID", book.getBookId());
			jsonObj.put("ISBN", book.getIsbn());
			jsonObj.put("BOOKNAME", book.getBookName());
			jsonObj.put("BOOKPRICE", book.getBookPrice());
			jsonArray.put(jsonObj);
		}
		jsonObject.put("books", jsonArray);
		System.out.println(jsonObject);
		return jsonObject.toString();
	}

	/*
	 * @RequestMapping(value="/bookSubmitForm",method=RequestMethod.POST) public
	 * ModelAndView getBookDetails(@ModelAttribute Book book,BindingResult
	 * result){ if(result.hasErrors()) return new ModelAndView("bookForm");
	 * return new ModelAndView("displayBookDetails");
	 * 
	 * }
	 */

	@RequestMapping(value = "/saveBookDetails", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String saveBookDetails(@RequestBody Book book, HttpServletRequest request, HttpServletResponse response) {
		System.out.println("inside saveBookDetails");
		System.out.println(
				"came upto here ======>    " + book.getBookName() + "\t" + book.getBookPrice() + "\t" + book.getIsbn());
		boolean res = iBookService.saveBookDetails(book);
		return getBookDetails(request, response);

	}

	@RequestMapping(value = "/getBookById", method = RequestMethod.GET)
	public String getBookById(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("getBookById");
		System.out.println(request.getParameter("bookId"));
		Book book = null;
		try {
			book = iBookService.getBook(new Integer(request.getParameter("bookId")));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("BOOKID", book.getBookId());
		jsonObject.put("ISBN", book.getIsbn());
		jsonObject.put("BOOKNAME", book.getBookName());
		jsonObject.put("BOOKPRICE", book.getBookPrice());
		System.out.println(jsonObject);
		return jsonObject.toString();
	}

}
