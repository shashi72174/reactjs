import React from "react"
class ClearComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fullName : ""
    }
  }
  handleFullNameChange(e) {
    this.setState({fullName : e.target.value});
  }
  handleSubmit(e) {
    alert(this.state.fullName);
    console.log(this.state.fullName);
  }
  handleClear(e) {
    alert(this.state.fullName);
    this.setState({fullName : ""});
  }
  render() {
    return (
      <div>
        <form>
          <label htmlFor="fullName">Full Name</label>
            <input
              type="text"
              value={this.state.fullName}
              onChange={this.handleFullNameChange.bind(this)}
              name="fullName" />
          <input type="button" value="Submit" onClick={this.handleSubmit.bind(this)}/>
          <input type="button" value="Clear" onClick={this.handleClear.bind(this)}/>
        </form>
      </div>
    );
  }
}

export default ClearComponent
