import React, { Component } from 'react';

class HelloWorldExample extends Component {
  constructor() {
    super();
    this.state = {name : '',
                  categories : ['Application Development', 'Database Development', 'UI Development']
  }
  }
  handleSubmit(e) {
				alert('inside handleSubmit');
				var title = this.refs.titleName.value;
				var category = this.refs.category.value;
				alert('title ====>'+title+' category ====>'+category);
				this.setState({newProject :
				{
					"title" : title,
					"category" : category
				}
				},function() {
					console.log(this.state);
					this.props.addProject(this.state.newProject);
				});
				e.preventDefault();
		}
		handleClear(e) {
				alert('inside handleClear');
				document.getElementById('formId').reset();
		}
		handleNameChange(e) {
				alert('inside handleNameChange');
				var changedName = this.state.name;
				alert(changedName);
		}
  render() {
    console.log(this.props.categories);
		console.log(this.state.newProject);
		var categoryOptions;
		if(this.state.categories) {
			alert('inside if block of this.props.categories');
			categoryOptions = this.state.categories.map(category => {
			//console.log(project);
			return (<option key = {category} value = {category}>{category}</option>);
			});
			alert('categoryOptions =====> '+categoryOptions);
		}
    return (
      <div>
        <h1>Hello World!!!!</h1>
        <form onSubmit={this.handleSubmit.bind(this)} id="formId">
							<label>Title:</label>
							<input type="text" value={this.state.name} name="name"/><br/>
							<label>Category:</label>
							<select ref="category">
								{categoryOptions}
							</select>
							<br/>
							<input type="button" value="Submit"/>
							<input type="button" value="Clear" onClick={this.handleClear.bind(this)}/>
						</form>
      </div>

    );

  }
}

export default HelloWorldExample;
