import React, { Component } from 'react';

class ControlledCompExample extends Component {

  constructor() {
    super();

    this.state = {
        fullName: ''
    }

  }
  handleFullNameChange(e) {
    //alert(e.target.value);
    this.setState({
      fullName: e.target.value
    })

  }
  handleSubmit(e) {
    e.preventDefault();
    console.log(this.state.fullName)
  }
  render() {
    //alert('render called from ControlledCompExample');
    var changeName = this.state.fullName;
    //alert('changeName =================> '+changeName);
    return (
      <div>
        <form>
          <label htmlFor="fullName">Full Name</label>
            <input
              type="text"
              value={this.state.fullName}
              onChange={this.handleFullNameChange.bind(this)}
              name="fullName" />
          <input type="button" value="Submit" onClick={this.handleSubmit.bind(this)}/>
        </form>
      </div>
    );
  }
}

export default ControlledCompExample;
