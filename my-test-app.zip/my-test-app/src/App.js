import React, { Component } from 'react';

class App extends Component {

  constructor(props) {
    super(props);
    alert('constructor called');
    console.log(props);
		this.state = {
      checked : true,

    }
	}

	handleChange() {
    var _this = this;
		_this.setState({checked : !this.state.checked});
	}

	handleSubmit() {
    alert(this.refs.txtName.value);
		console.log(this.refs.txtName.value);
	}

  displayContent() {
		var spaces = "                      ";
		return (<div>This will show if you select the checkbox otehrwise it will be hidden
        			<form>
        				<input type="text" id="id" placeholder = "Name" ref="txtName"/>{spaces}
        				<input type="button" value="Submit" onClick={this.handleSubmit.bind(this)} />
        			</form>
	          </div>);
	}

	displayNothing() {
		return (<p>Hi, You have not selected the checkbox</p>);
	}

  componentWillMount() {
    alert('componentWillMount called');

  }

  componentDidMount() {
    alert('componentDidMount called');
  }

  render() {
    alert('render called');
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
        <input type="checkbox" value="Check This" onChange={this.handleChange.bind(this)} defaultChecked = {this.state.checked}/>
							{(this.state.checked) ? this.displayContent(): this.displayNothing()}

      </div>
    );
  }
}

export default App;
